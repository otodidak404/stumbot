# bot-stumble
Push Rank Stumble Guys

# Cara Jalanin
 - install Http Canary di HP, jalanin Http Canary nya. Terus mainin Stumble Guys sampe juara 1 atau minimal masuk ronde 3
 - $ pkg install python3 (skip aja kalo udah)
 - $ git clone https://github.com/otodidak404/stumbot
 - $ copy authorization dari Http Canary (cek file auth.txt buat contohnya)
 - paste authorization ke file auth.txt
 - $ cd bot-stumble
 - $ python3 push_rank.py
 
 # NB:
 jangan tutup aplikasi stumble ketika jalanin botnya
